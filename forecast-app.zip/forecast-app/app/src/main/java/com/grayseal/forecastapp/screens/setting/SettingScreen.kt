package com.grayseal.forecastapp.screens

import androidx.compose.runtime.Composable
import androidx.navigation.NavController

@Composable
fun SettingScreen(navController: NavController){

}