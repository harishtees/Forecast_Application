package com.grayseal.forecastapp.model

data class Rain(
    val `1h`: Double
)