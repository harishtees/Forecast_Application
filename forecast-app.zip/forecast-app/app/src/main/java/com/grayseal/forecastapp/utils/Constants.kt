package com.grayseal.forecastapp.utils

object Constants {
    const val BASE_URL = "https://api.openweathermap.org/"
    const val API_KEY = "f8b001a08778c78e5b8f87c14b36c269"
}