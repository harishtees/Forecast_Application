package com.grayseal.forecastapp.ui.theme

import androidx.compose.ui.graphics.Color

val NavyBlue = Color(0xFF0a154b)
val Blue = Color(0xFF3092e8)
val LightNavyBlue = Color(0xFF23224a)
val White = Color(0xFFFFFFFF)